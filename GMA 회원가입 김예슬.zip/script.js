const email = document.querySelector("#email");
const name = document.querySelector("#name");
const pw = document.querySelector("#pw");
const pw_re = document.querySelector("#pw-re");
let login_num = document.querySelector(".login-number")

function validate() {
  if (!(email.value && name.value && pw.value && pw_re.value && login_num.value)) {
  }
}

const send = document.querySelector("#num-send");
const check = document.querySelector("#num-checked");
const login_num = document.querySelector(".login-num");

const number = Math.random();
const token = Math.floor(number * 1000000);
const paddenToken = String(token).padStart(6, "0");
document.write(paddenToken);

